<nav>
  <ul class="nav nav-tabs">
    <li role="presentation"><a href="new_game_code.php">New Game Code</a></li>
    <li role="presentation"><a href="game_codes.php">Game Codes</a></li>
    <li role="presentation"><a href="new_game.php">New Game</a></li>
    <li role="presentation"><a href="games.php">Games</a></li>
    <li role="presentation"><a href="logout.php">Logout</a></li>
  </ul>
</nav>