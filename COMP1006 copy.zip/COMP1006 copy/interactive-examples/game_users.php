<?php

  require 'class.interative_example_users.php';

  $ieu = new InteractiveExampleUsers();

  $results = $ieu->getAllUsers();

?>